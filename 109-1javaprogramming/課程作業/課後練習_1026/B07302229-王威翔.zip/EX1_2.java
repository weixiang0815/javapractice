
public class EX1_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int t=0,n=100;
		while(n>=1) {
				t++;
				n/=2;
		}
		System.out.print(t);
	}

}
