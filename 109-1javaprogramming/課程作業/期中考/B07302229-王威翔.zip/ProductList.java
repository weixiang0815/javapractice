import java.util.ArrayList;
public class ProductList{
	public static void main(String[] args) {
		ArrayList Product=new ArrayList();
		}
	}